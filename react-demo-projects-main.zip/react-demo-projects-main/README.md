# React JS Workshop

Four small, independent React applications for a beginner React workshop. Each one
is a separate React + Vite project with its own dependencies, and each one talks to
a REST API with `fetch()`.

| Project                                 | What you build                                              | API          | CRUD used              |
| --------------------------------------- | ----------------------------------------------------------- | ------------ | ---------------------- |
| [todo-list](./todo-list)                | Tasks with add, edit, complete, delete, and filters          | MockAPI.io   | GET, POST, PUT, DELETE |
| [quiz-app](./quiz-app)                  | A quiz, plus a screen to manage its questions                | MockAPI.io   | GET, POST, PUT, DELETE |
| [expense-tracker](./expense-tracker)    | Expenses with categories and calculated totals               | MockAPI.io   | GET, POST, PUT, DELETE |
| [pokedex](./pokedex)                    | A searchable Pokedex with a detail dialog                    | PokeAPI      | GET                    |

The first three use [MockAPI.io](https://mockapi.io/?utm_source=chatgpt.com), where you
create the data yourself and practise full CRUD. The Pokedex uses the free public
[PokeAPI](https://pokeapi.co/) instead — no account needed — to show what it is like to
read from an API somebody else built.

## Start here

1. **Set up the backend first:** follow [MOCKAPI_SETUP.md](./MOCKAPI_SETUP.md) to create
   your free MockAPI.io project and the `todos`, `questions`, and `expenses` resources.
   (The Pokedex needs no setup — skip ahead to it if you want to start coding immediately.)
2. Pick a project folder and follow its own README.

Each project starts the same way:

```bash
cd todo-list        # or quiz-app, expense-tracker, or pokedex
npm install
cp .env.example .env   # PowerShell: Copy-Item .env.example .env
# paste your MockAPI.io URL into .env (the pokedex value already works as-is)
npm run dev
```

If you want to run two apps at the same time, start the second one on another port:

```bash
npm run dev -- --port 5174
```

## Stack

React · Vite · JavaScript · Tailwind CSS · shadcn/ui · MockAPI.io · PokeAPI · Fetch API · npm

No TypeScript, no state-management library, no data-fetching library, no backend code —
just React, `fetch`, and a REST API.

## React concepts covered

```text
Components        Conditional rendering
Props             Array.map()
useState          Array.filter()
useEffect         Fetch API
Event handlers    async / await
Forms             Loading states
Controlled inputs Error states
```

The Pokedex adds one idea the other three do not cover: a `useEffect` with a
**dependency** (`[name]`), which re-runs when its input changes, in a child component
that fetches its own data.
