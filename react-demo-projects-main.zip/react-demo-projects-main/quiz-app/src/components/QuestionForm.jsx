import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

// Labels shown in front of each option box.
const letters = ['A', 'B', 'C', 'D']

// This form is used twice: to add a new question and to edit an existing one.
// `question` is optional - when it is given, the inputs start with its values.
function QuestionForm({ onSubmit, question, submitLabel = 'Add Question' }) {
  const [text, setText] = useState(question ? question.question : '')
  // Four option boxes, stored as one array in state.
  const [options, setOptions] = useState(
    question && Array.isArray(question.options)
      ? [...question.options]
      : ['', '', '', ''],
  )
  const [answer, setAnswer] = useState(question ? question.answer : '')
  const [formError, setFormError] = useState('')

  // Changing one item in an array of state: make a copy, change the copy,
  // then put the copy in state. Never change the original array directly.
  function handleOptionChange(index, value) {
    const nextOptions = [...options]
    nextOptions[index] = value
    setOptions(nextOptions)
  }

  // Only options that actually have text can be picked as the answer.
  const filledOptions = options.filter((option) => option.trim() !== '')

  function handleSubmit(event) {
    event.preventDefault()

    if (text.trim() === '') {
      setFormError('Please type the question.')
      return
    }

    if (filledOptions.length < 4) {
      setFormError('Please fill in all four options.')
      return
    }

    if (!options.map((option) => option.trim()).includes(answer)) {
      setFormError('Please choose which option is the correct answer.')
      return
    }

    setFormError('')

    onSubmit({
      question: text.trim(),
      options: options.map((option) => option.trim()),
      answer: answer,
    })

    // Only clear the form when we are adding a brand new question.
    if (!question) {
      setText('')
      setOptions(['', '', '', ''])
      setAnswer('')
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="question">Question</Label>
        <Input
          id="question"
          placeholder="What is React?"
          value={text}
          onChange={(event) => setText(event.target.value)}
        />
      </div>

      <div className="space-y-2">
        <Label>Options</Label>
        {/* Array.map() builds the four inputs from the options array */}
        {options.map((option, index) => (
          <div key={index} className="flex items-center gap-2">
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded border text-xs font-medium">
              {letters[index]}
            </span>
            <Input
              placeholder={'Option ' + letters[index]}
              value={option}
              onChange={(event) => handleOptionChange(index, event.target.value)}
            />
          </div>
        ))}
      </div>

      <div className="space-y-2">
        <Label htmlFor="answer">Correct answer</Label>
        <Select value={answer} onValueChange={setAnswer}>
          <SelectTrigger id="answer" className="w-full">
            <SelectValue placeholder="Pick the correct option" />
          </SelectTrigger>
          <SelectContent>
            {/* The choices here come from what you typed above */}
            {filledOptions.map((option) => (
              <SelectItem key={option} value={option}>
                {option}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {filledOptions.length === 0 && (
          <p className="text-xs text-slate-500">
            Type the four options first, then pick the correct one here.
          </p>
        )}
      </div>

      {/* Conditional rendering: the message only appears when there is a problem */}
      {formError && <p className="text-sm text-red-600">{formError}</p>}

      <Button type="submit" className="w-full">
        {submitLabel}
      </Button>
    </form>
  )
}

export default QuestionForm
