import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

const letters = ['A', 'B', 'C', 'D']

function QuestionListItem({ question, number, onEdit, onDelete }) {
  // Guard against a question whose options were not saved as an array.
  const options = Array.isArray(question.options) ? question.options : []

  return (
    <li className="space-y-3 p-3">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
        <p className="text-sm font-medium">
          {number}. {question.question}
        </p>

        <div className="flex shrink-0 gap-2">
          <Button size="sm" variant="outline" onClick={() => onEdit(question)}>
            Edit
          </Button>
          <Button
            size="sm"
            variant="destructive"
            onClick={() => onDelete(question.id)}
          >
            Delete
          </Button>
        </div>
      </div>

      {/* Viewing the options, with the correct one marked */}
      <ul className="space-y-1">
        {options.map((option, index) => (
          <li key={option} className="flex items-center gap-2 text-sm">
            <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded border text-xs">
              {letters[index]}
            </span>
            <span className="text-slate-600">{option}</span>
            {/* Conditional rendering: only the right answer gets a badge */}
            {option === question.answer && (
              <Badge variant="secondary">Correct</Badge>
            )}
          </li>
        ))}
      </ul>
    </li>
  )
}

export default QuestionListItem
