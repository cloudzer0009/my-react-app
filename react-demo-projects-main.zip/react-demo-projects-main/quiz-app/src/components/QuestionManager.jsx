import QuestionForm from './QuestionForm'
import QuestionListItem from './QuestionListItem'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

function QuestionManager({ questions, onAdd, onEdit, onDelete }) {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Add a question</CardTitle>
        </CardHeader>
        <CardContent>
          <QuestionForm onSubmit={onAdd} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Questions ({questions.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {/* Empty state */}
          {questions.length === 0 ? (
            <p className="py-8 text-center text-sm text-slate-500">
              No questions yet. Add your first one above.
            </p>
          ) : (
            <ul className="divide-y rounded-md border">
              {/* Array.map() turns each question into a row */}
              {questions.map((question, index) => (
                <QuestionListItem
                  key={question.id}
                  question={question}
                  number={index + 1}
                  onEdit={onEdit}
                  onDelete={onDelete}
                />
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default QuestionManager
