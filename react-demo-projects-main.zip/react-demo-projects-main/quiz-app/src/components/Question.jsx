import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'

// Labels shown in front of each option.
const letters = ['A', 'B', 'C', 'D']

function Question({
  question,
  questionNumber,
  totalQuestions,
  selectedAnswer,
  onSelectAnswer,
  onNext,
}) {
  // MockAPI.io should send `options` as an array. If it is not an array
  // (a common setup mistake) we show a helpful message instead of crashing.
  const options = Array.isArray(question.options) ? question.options : []

  // How far through the quiz we are, as a percentage.
  const progress = ((questionNumber - 1) / totalQuestions) * 100

  const isLastQuestion = questionNumber === totalQuestions

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <Badge variant="secondary">
            Question {questionNumber} of {totalQuestions}
          </Badge>
        </div>
        <Progress value={progress} className="mt-3" />
        <CardTitle className="pt-4 text-lg sm:text-xl">{question.question}</CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        {options.length === 0 ? (
          <p className="text-sm text-red-600">
            This question has no options. In MockAPI.io the <code>options</code> field
            must be an array of four answers.
          </p>
        ) : (
          <div className="space-y-2">
            {options.map((option, index) => (
              <button
                key={option}
                type="button"
                onClick={() => onSelectAnswer(option)}
                className={
                  'flex w-full items-center gap-3 rounded-md border p-3 text-left text-sm ' +
                  (selectedAnswer === option
                    ? 'border-slate-900 bg-slate-100'
                    : 'border-slate-200 hover:bg-slate-50')
                }
              >
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded border text-xs font-medium">
                  {letters[index]}
                </span>
                <span>{option}</span>
              </button>
            ))}
          </div>
        )}

        <div className="flex flex-col gap-2 border-t pt-4 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm text-slate-500">
            {selectedAnswer === null
              ? 'Select an answer to continue.'
              : 'Answer selected.'}
          </p>

          {/* The button stays disabled until the user picks an answer. */}
          <Button onClick={onNext} disabled={selectedAnswer === null}>
            {isLastQuestion ? 'Finish Quiz' : 'Next Question'}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

export default Question
