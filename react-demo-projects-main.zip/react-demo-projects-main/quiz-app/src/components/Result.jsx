import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'

function Result({ score, totalQuestions, onRestart }) {
  // We calculate the percentage from the score instead of storing it in state.
  const percentage = Math.round((score / totalQuestions) * 100)

  return (
    <Card>
      <CardHeader>
        <CardTitle>Quiz finished</CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="text-center">
          <p className="text-4xl font-bold">
            {score} / {totalQuestions}
          </p>
          <p className="mt-1 text-sm text-slate-600">{percentage}% correct</p>
        </div>

        <Progress value={percentage} />

        <p className="text-center text-sm text-slate-600">
          {percentage === 100
            ? 'Perfect score. Well done!'
            : percentage >= 50
              ? 'Nice work. Try again to improve your score.'
              : 'Keep practising and give it another go.'}
        </p>

        <Button className="w-full" onClick={onRestart}>
          Restart Quiz
        </Button>
      </CardContent>
    </Card>
  )
}

export default Result
