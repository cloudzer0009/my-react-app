import QuestionForm from './QuestionForm'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'

function EditQuestionDialog({ question, onSave, onClose }) {
  return (
    // `open` is always true here because QuestionManager only renders this
    // component while a question is being edited.
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit question</DialogTitle>
          <DialogDescription>
            Update the values and save to send a PUT request to MockAPI.io.
          </DialogDescription>
        </DialogHeader>

        {/* We reuse the same form we use for adding questions. */}
        <QuestionForm
          question={question}
          submitLabel="Save Changes"
          onSubmit={(updated) => onSave(question.id, updated)}
        />
      </DialogContent>
    </Dialog>
  )
}

export default EditQuestionDialog
