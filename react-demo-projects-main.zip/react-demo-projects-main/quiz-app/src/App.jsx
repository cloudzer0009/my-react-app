import { useState, useEffect } from 'react'
import { API_URL, QUESTIONS_URL } from './api'
import Question from './components/Question'
import Result from './components/Result'
import QuestionManager from './components/QuestionManager'
import EditQuestionDialog from './components/EditQuestionDialog'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'

function App() {
  // The questions we downloaded from MockAPI.io
  const [questions, setQuestions] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  // Which screen are we on: "quiz" or "manage"
  const [view, setView] = useState('quiz')
  // The question being edited right now (null = the dialog is closed)
  const [editingQuestion, setEditingQuestion] = useState(null)

  // Which question are we on? 0 means the first one.
  const [currentIndex, setCurrentIndex] = useState(0)
  // The answer text the user clicked (null = nothing selected yet)
  const [selectedAnswer, setSelectedAnswer] = useState(null)
  // How many questions the user got right
  const [score, setScore] = useState(0)
  // True once the user answered the last question
  const [isFinished, setIsFinished] = useState(false)

  // GET /questions -> read every quiz question
  async function loadQuestions() {
    setLoading(true)
    setError('')

    try {
      if (!API_URL) {
        throw new Error('VITE_API_URL is missing. Copy .env.example to .env and add your MockAPI.io URL.')
      }

      const response = await fetch(QUESTIONS_URL)

      if (!response.ok) {
        throw new Error('Could not load questions (status ' + response.status + ')')
      }

      const data = await response.json()
      setQuestions(data)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  // Load the questions once, right after the first render.
  useEffect(() => {
    loadQuestions()
  }, [])

  // POST /questions -> create one question
  async function addQuestion(question) {
    try {
      const response = await fetch(QUESTIONS_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(question),
      })

      if (!response.ok) {
        throw new Error('Could not add the question')
      }

      const newQuestion = await response.json()
      setQuestions([...questions, newQuestion])
      // The quiz now has a different number of questions, so start it over.
      restartQuiz()
    } catch (err) {
      setError(err.message)
    }
  }

  // PUT /questions/:id -> update one question
  async function updateQuestion(id, question) {
    try {
      const response = await fetch(`${QUESTIONS_URL}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(question),
      })

      if (!response.ok) {
        throw new Error('Could not update the question')
      }

      const updatedQuestion = await response.json()
      // Replace the old question with the updated one.
      setQuestions(
        questions.map((item) => (item.id === id ? updatedQuestion : item)),
      )
      setEditingQuestion(null) // close the dialog
      restartQuiz()
    } catch (err) {
      setError(err.message)
    }
  }

  // DELETE /questions/:id -> remove one question
  async function deleteQuestion(id) {
    try {
      const response = await fetch(`${QUESTIONS_URL}/${id}`, { method: 'DELETE' })

      if (!response.ok) {
        throw new Error('Could not delete the question')
      }

      // Keep every question except the deleted one.
      setQuestions(questions.filter((item) => item.id !== id))
      restartQuiz()
    } catch (err) {
      setError(err.message)
    }
  }

  function handleSelectAnswer(option) {
    setSelectedAnswer(option)
  }

  function handleNextQuestion() {
    // The button is disabled until an answer is picked, so this is just a guard.
    if (selectedAnswer === null) return

    // Was the selected answer correct?
    if (selectedAnswer === questions[currentIndex].answer) {
      setScore(score + 1)
    }

    const isLastQuestion = currentIndex === questions.length - 1

    if (isLastQuestion) {
      setIsFinished(true)
    } else {
      setCurrentIndex(currentIndex + 1)
      setSelectedAnswer(null) // clear the selection for the next question
    }
  }

  // Put every piece of quiz state back to its starting value. We call this
  // from the Restart button and after any change to the question list.
  function restartQuiz() {
    setCurrentIndex(0)
    setSelectedAnswer(null)
    setScore(0)
    setIsFinished(false)
  }

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4">
      <div className="mx-auto w-full max-w-2xl">
        <header className="mb-6">
          <h1 className="text-2xl font-bold sm:text-3xl">Quiz App</h1>
          <p className="mt-1 text-sm text-slate-600">
            A React + MockAPI.io workshop project.
          </p>
        </header>

        {/* Two buttons that switch between the two screens */}
        <div className="mb-4 flex gap-2">
          <Button
            size="sm"
            variant={view === 'quiz' ? 'default' : 'outline'}
            onClick={() => setView('quiz')}
          >
            Take Quiz
          </Button>
          <Button
            size="sm"
            variant={view === 'manage' ? 'default' : 'outline'}
            onClick={() => setView('manage')}
          >
            Manage Questions
          </Button>
        </div>

        {/* Error state */}
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertTitle>Something went wrong</AlertTitle>
            <AlertDescription>
              <p>{error}</p>
              <Button size="sm" variant="outline" onClick={loadQuestions}>
                Try again
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {/* Loading state */}
        {loading && (
          <Card>
            <CardContent className="py-10 text-center text-sm text-slate-500">
              Loading questions...
            </CardContent>
          </Card>
        )}

        {/* ---------- The manage screen ---------- */}
        {!loading && view === 'manage' && (
          <QuestionManager
            questions={questions}
            onAdd={addQuestion}
            onEdit={setEditingQuestion}
            onDelete={deleteQuestion}
          />
        )}

        {/* The dialog only exists while a question is being edited. */}
        {editingQuestion && (
          <EditQuestionDialog
            question={editingQuestion}
            onSave={updateQuestion}
            onClose={() => setEditingQuestion(null)}
          />
        )}

        {/* ---------- The quiz screen ---------- */}
        {!loading && view === 'quiz' && !error && questions.length === 0 && (
          <Card>
            <CardHeader>
              <CardTitle>No questions yet</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm text-slate-600">
              <p>Add your first question to start the quiz.</p>
              <Button size="sm" onClick={() => setView('manage')}>
                Go to Manage Questions
              </Button>
            </CardContent>
          </Card>
        )}

        {!loading && view === 'quiz' && questions.length > 0 && !isFinished && (
          <Question
            question={questions[currentIndex]}
            questionNumber={currentIndex + 1}
            totalQuestions={questions.length}
            selectedAnswer={selectedAnswer}
            onSelectAnswer={handleSelectAnswer}
            onNext={handleNextQuestion}
          />
        )}

        {!loading && view === 'quiz' && questions.length > 0 && isFinished && (
          <Result
            score={score}
            totalQuestions={questions.length}
            onRestart={restartQuiz}
          />
        )}
      </div>
    </div>
  )
}

export default App
