# Quiz App

A beginner-friendly React quiz that loads its questions from [MockAPI.io](https://mockapi.io/?utm_source=chatgpt.com).

## Project Overview

This app has two screens, switched with the buttons at the top.

**Take Quiz** runs a multiple-choice quiz:

- Questions are downloaded from MockAPI.io (nothing is hardcoded in the components)
- One question is shown at a time, with four answers
- You pick an answer, then press **Next Question**
- The **Next** button stays disabled until you choose an answer
- Your progress is shown as `Question 2 of 5` plus a progress bar
- Your score is counted as you go
- At the end you see your score, your percentage, and a **Restart Quiz** button

**Manage Questions** is a full CRUD screen for the quiz content:

- **View** every question with its four options, and a badge on the correct one
- **Add** a question: type it, fill the four options, then pick which one is correct
- **Edit** a question in a dialog
- **Delete** a question
- The form checks your input before sending anything to the API

Anything you change here shows up in the quiz straight away — add a question and the
quiz becomes `Question 1 of 6`. This means you never have to type quiz data into the
MockAPI.io dashboard by hand.

Both screens share friendly **loading**, **error**, and **empty** states.

Example of one question:

```text
Question 2 of 5

What is React?

[ A ] A JavaScript library
[ B ] A database
[ C ] An operating system
[ D ] A programming language

[ Next Question ]
```

## Technologies

- **React** – builds the user interface out of components
- **Vite** – the dev server and build tool
- **Tailwind CSS** – utility classes for styling
- **shadcn/ui** – ready-made, accessible components (Button, Card, Progress, Badge, Alert)
- **MockAPI.io** – a free fake REST API that stores the questions
- **Fetch API** – how the browser talks to MockAPI.io

## Prerequisites

- [Node.js](https://nodejs.org/) (version 20 or newer)
- npm (comes with Node.js)
- [Git](https://git-scm.com/)
- A free [MockAPI.io](https://mockapi.io/?utm_source=chatgpt.com) account

If you have not created your MockAPI.io project yet, follow **[../MOCKAPI_SETUP.md](../MOCKAPI_SETUP.md)** first.

## Installation

```bash
npm install
```

## Environment Setup

Copy:

```text
.env.example
```

to:

```text
.env
```

On macOS / Linux:

```bash
cp .env.example .env
```

On Windows (PowerShell):

```powershell
Copy-Item .env.example .env
```

Then open `.env` and paste in your own MockAPI.io URL:

```env
VITE_API_URL=https://YOUR_PROJECT_ID.mockapi.io/api/v1
```

Notes:

- Do **not** put `/questions` at the end. The app adds it for you.
- Variables must start with `VITE_` or Vite will not pass them to the browser.
- Restart `npm run dev` after changing `.env`.
- `.env` is listed in `.gitignore`, so your URL is never committed.

## Run the Project

```bash
npm run dev
```

Then open the address Vite prints (usually http://localhost:5173).

## Build

```bash
npm run build
```

## Preview

```bash
npm run preview
```

## API

This app uses one MockAPI.io resource: **`questions`**.

| Field      | Type   | Example                                  |
| ---------- | ------ | ---------------------------------------- |
| `question` | string | `"What is React?"`                       |
| `options`  | array  | `["A JavaScript library", "A database", "An operating system", "A programming language"]` |
| `answer`   | string | `"A JavaScript library"`                 |

`answer` must be **exactly the same text** as one of the items in `options` — that is how the app knows you were right.

| Method   | Endpoint          | Used for                                   |
| -------- | ----------------- | ------------------------------------------ |
| `GET`    | `/questions`      | Loading every question when the page opens |
| `POST`   | `/questions`      | Adding a question on the Manage screen     |
| `PUT`    | `/questions/:id`  | Saving an edit                             |
| `DELETE` | `/questions/:id`  | Removing a question                        |

All four live in `src/App.jsx`. The base URL comes from `src/api.js`:

```js
export const API_URL = import.meta.env.VITE_API_URL
export const QUESTIONS_URL = `${API_URL}/questions`
```

## Project Structure

```text
src/
├── components/
│   ├── ui/                     # shadcn/ui components
│   ├── Question.jsx            # one question, four options, Next button
│   ├── Result.jsx              # final score, percentage, restart
│   ├── QuestionManager.jsx     # the Manage screen: add form + list
│   ├── QuestionForm.jsx        # used for both adding and editing
│   ├── QuestionListItem.jsx    # one question with its options + buttons
│   └── EditQuestionDialog.jsx  # the edit dialog
├── api.js                      # reads VITE_API_URL
├── App.jsx                     # state + all fetch calls + quiz logic
├── main.jsx                    # starts React
└── index.css                   # Tailwind + theme
```

## Learning Objectives

By reading and changing this project you practise:

- **Components and props** – `App.jsx` passes the current question and callbacks down the tree
- **useState** – questions, loading, error, which screen, current index, selected answer, score, finished
- **useEffect** – fetching the questions once when the app starts
- **Event handlers** – selecting an answer, next question, restarting, switching screens, add / edit / delete
- **Forms and controlled inputs** – the question box, four option boxes, and the answer dropdown
- **Form validation** – no empty question, all four options filled, a correct answer chosen
- **Updating an array in state** – `handleOptionChange` copies the array, changes the copy,
  then stores the copy. This is the big new idea on the Manage screen.
- **Conditional rendering** – loading vs. error vs. empty vs. quiz vs. result vs. manage
- **`Array.map()`** – answer buttons, option inputs, the question list
- **`Array.filter()`** – removing a deleted question, and listing only the filled-in options
- **Fetch API with async/await** – `GET`, `POST`, `PUT`, and `DELETE` wrapped in `try / catch / finally`
- **Derived values** – the percentage and the answer choices are calculated during render
- **Reusing one component** – the same `QuestionForm` both adds and edits
- **Disabled buttons** – you cannot continue without choosing an answer

### Things to try on your own

1. Show whether the answer was right or wrong before moving on.
2. Add a "Previous question" button.
3. Shuffle the questions each time the quiz starts.
4. Ask for confirmation before deleting a question.
5. Let a question have a different number of options instead of always four.
