# MockAPI.io Setup Guide

This guide walks you through creating the fake backend that all three workshop
projects talk to. You only need to do this **once** — the same MockAPI.io project
serves the Todo List, the Quiz App, and the Expense Tracker.

No coding is needed here. Everything happens in your browser.

**What you will end up with:** one project URL that looks like this:

```text
https://YOUR_PROJECT_ID.mockapi.io/api/v1
```

...and three resources inside it: `todos`, `questions`, and `expenses`.

---

## 1. Create a MockAPI.io Account

1. Open [MockAPI.io](https://mockapi.io/?utm_source=chatgpt.com).
2. Click **Sign In** (or **Get started**).
3. Sign in with GitHub or Google, or create an account with your email.
4. The free plan is enough for this workshop.

---

## 2. Create the Project

1. On your dashboard, click **New Project** (the big **+** button).
2. Give it a name, for example `react-workshop`.
3. Leave the API prefix as the default `api/v1`.
4. Click **Create**.

Open the project. Near the top of the page MockAPI.io shows your **project URL**:

```text
https://YOUR_PROJECT_ID.mockapi.io/api/v1
```

`YOUR_PROJECT_ID` is a long string of letters and numbers that is unique to you.
Copy that URL somewhere safe — you will paste it into three `.env` files later.

> The `YOUR_PROJECT_ID` above is a placeholder. It is **not** a working endpoint.
> Nothing will load until you replace it with your own project's URL.

---

## 3. Create `todos`

Inside your project, click **New resource**.

- **Resource name:** `todos`
- Add these fields:

| Field name  | Type    |
| ----------- | ------- |
| `title`     | String  |
| `completed` | Boolean |

Click **Create**. MockAPI.io adds an `id` field automatically — you never create it yourself.

MockAPI.io usually generates some random rows for you. Click on the `todos`
resource to see the data, then use **Edit** on a row (or **Add** / the **+** button)
to replace them with something readable:

```json
{ "title": "Learn React", "completed": false }
```

```json
{ "title": "Build a todo app", "completed": true }
```

```json
{ "title": "Practice fetch()", "completed": false }
```

Make sure `completed` is a real `true` / `false` value, not the text `"true"`.

---

## 4. Create `questions`

Click **New resource** again.

- **Resource name:** `questions`
- Add these fields:

| Field name | Type   |
| ---------- | ------ |
| `question` | String |
| `options`  | Array  |
| `answer`   | String |

### How to store the `options` array

`options` must be an **array of four strings**. In the MockAPI.io data editor the
value is written as JSON, so it looks like this:

```json
["A JavaScript library", "A database", "An operating system", "A programming language"]
```

Two rules to remember:

1. Use square brackets `[ ]` and put each option in double quotes.
2. The value of `answer` must be **exactly** one of the strings inside `options` —
   same spelling, same capitalisation, no extra spaces. That is how the Quiz App
   decides whether you were right.

If `options` is saved as plain text instead of an array, the Quiz App will show a
message telling you so.

### Sample questions

You have two ways to get questions in:

- **Type them in MockAPI.io**, using the records below.
- **Use the app itself.** The Quiz App has a **Manage Questions** screen that can add,
  edit, and delete questions for you. If you prefer that, create the `questions`
  resource with the three fields above and let the app fill it.

Either way it is the same data. Here are five records to start with:

```json
{
  "question": "What is React?",
  "options": [
    "A JavaScript library",
    "A database",
    "An operating system",
    "A programming language"
  ],
  "answer": "A JavaScript library"
}
```

```json
{
  "question": "Which hook lets a component remember a value?",
  "options": ["useEffect", "useState", "useFetch", "useMemo"],
  "answer": "useState"
}
```

```json
{
  "question": "How do you pass data from a parent component to a child?",
  "options": ["With props", "With state", "With a hook", "With CSS"],
  "answer": "With props"
}
```

```json
{
  "question": "Which array method is normally used to render a list in JSX?",
  "options": ["push()", "map()", "sort()", "join()"],
  "answer": "map()"
}
```

```json
{
  "question": "When does useEffect with an empty [] run?",
  "options": [
    "After every render",
    "Only after the first render",
    "Never",
    "Before the component renders"
  ],
  "answer": "Only after the first render"
}
```

---

## 5. Create `expenses`

Click **New resource** one more time.

- **Resource name:** `expenses`
- Add these fields:

| Field name    | Type   |
| ------------- | ------ |
| `description` | String |
| `amount`      | Number |
| `category`    | String |

`category` must be one of: `Food`, `Transportation`, `Shopping`, `Entertainment`,
`Bills`, `Other`.

### Sample expenses

```json
{ "description": "Lunch", "amount": 150, "category": "Food" }
```

```json
{ "description": "Jeepney fare", "amount": 30, "category": "Transportation" }
```

```json
{ "description": "Groceries", "amount": 1250, "category": "Shopping" }
```

```json
{ "description": "Movie ticket", "amount": 400, "category": "Entertainment" }
```

```json
{ "description": "Electricity bill", "amount": 2200, "category": "Bills" }
```

Keep `amount` a **number** (`150`), not text (`"150"`), so the totals add up correctly.

---

## 6. Configure React

Each project reads the API URL from a file called `.env`.

In **each** of the three project folders:

1. Copy `.env.example` to `.env`.

   macOS / Linux:

   ```bash
   cp .env.example .env
   ```

   Windows (PowerShell):

   ```powershell
   Copy-Item .env.example .env
   ```

2. Open `.env` and paste your own project URL:

   ```env
   VITE_API_URL=https://YOUR_PROJECT_ID.mockapi.io/api/v1
   ```

3. Save the file and restart the dev server (`Ctrl + C`, then `npm run dev`).

Rules for this file:

- The name **must** start with `VITE_`. Vite only sends `VITE_*` variables to the browser.
- Stop at `/api/v1`. Do **not** add `/todos`, `/questions`, or `/expenses` — the code adds those.
- No quotes and no spaces around the `=`.
- `.env` is already in `.gitignore`, so your URL never gets committed.

In the code, the value is read like this (see `src/api.js` in each project):

```js
const API_URL = import.meta.env.VITE_API_URL
```

`import.meta.env` is Vite's way of handing environment variables to your React code.
Because the URL lives in one place, no component ever hardcodes it.

---

## 7. Test the API

Before running React, check your endpoints straight in the browser. Replace
`YOUR_PROJECT_ID` with your own:

```text
https://YOUR_PROJECT_ID.mockapi.io/api/v1/todos
https://YOUR_PROJECT_ID.mockapi.io/api/v1/questions
https://YOUR_PROJECT_ID.mockapi.io/api/v1/expenses
```

Each one should return JSON — an array of objects wrapped in square brackets:

```json
[
  { "title": "Learn React", "completed": false, "id": "1" },
  { "title": "Build a todo app", "completed": true, "id": "2" }
]
```

What you might see instead:

| What you see              | What it usually means                                        |
| ------------------------- | ------------------------------------------------------------ |
| `[]` (empty brackets)     | The resource exists but has no records yet. Add some rows.    |
| `{"message":"Not found"}` | The resource name is misspelled, or the URL is wrong.         |
| A MockAPI.io error page   | The project ID in the URL is wrong.                           |

If the URL works in the browser, it will work in React too.

---

## 8. Explain CRUD

REST APIs use HTTP methods to describe what you want to do. CRUD is the short name
for the four basic operations:

```text
GET    → Read
POST   → Create
PUT    → Update
DELETE → Delete
```

How the three apps use them:

| App              | Method   | Endpoint         | What happens                      |
| ---------------- | -------- | ---------------- | --------------------------------- |
| Todo List        | `GET`    | `/todos`         | Show the list on page load        |
| Todo List        | `POST`   | `/todos`         | Add a new task                    |
| Todo List        | `PUT`    | `/todos/:id`     | Edit a title / tick a checkbox    |
| Todo List        | `DELETE` | `/todos/:id`     | Remove a task                     |
| Quiz App         | `GET`    | `/questions`     | Load the questions on page load   |
| Quiz App         | `POST`   | `/questions`     | Add a question on the Manage screen |
| Quiz App         | `PUT`    | `/questions/:id` | Save an edited question           |
| Quiz App         | `DELETE` | `/questions/:id` | Remove a question                 |
| Expense Tracker  | `GET`    | `/expenses`      | Show the expenses on page load    |
| Expense Tracker  | `POST`   | `/expenses`      | Add an expense                    |
| Expense Tracker  | `PUT`    | `/expenses/:id`  | Save an edit                      |
| Expense Tracker  | `DELETE` | `/expenses/:id`  | Remove an expense                 |

The `:id` part means "the id of one record", for example `/todos/3`.

In code, a `GET` is the short version:

```js
const response = await fetch(TODOS_URL)
const data = await response.json()
```

...and anything that sends data needs a method, a header, and a body:

```js
await fetch(TODOS_URL, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ title: 'Learn React', completed: false }),
})
```

`JSON.stringify()` turns a JavaScript object into text that can travel over the
internet. `response.json()` turns the text that comes back into a JavaScript object.

---

## 9. React + MockAPI Flow

Here is the whole round trip, from a click to the screen:

```text
React Component
      ↓
fetch()
      ↓
MockAPI.io
      ↓
JSON Response
      ↓
React State
      ↓
UI
```

In words:

1. Something happens — the page loads, or you click a button.
2. Your code calls `fetch()` with a URL (and a method, for writes).
3. MockAPI.io stores or looks up the data.
4. It sends JSON back.
5. You put that JSON into state with `setTodos(...)` / `setExpenses(...)`.
6. React re-renders, and the screen shows the new data.

React never talks to the database directly — it only ever talks to the API.

---

## Troubleshooting

| Problem                                             | Fix                                                                 |
| --------------------------------------------------- | ------------------------------------------------------------------- |
| "VITE_API_URL is missing"                           | You have no `.env` file, or the variable name is wrong.             |
| The app shows an error with status `404`            | Check the URL and the resource name, and that `/api/v1` is included. |
| Changes to `.env` do nothing                        | Restart `npm run dev` — Vite reads `.env` only on startup.          |
| Amounts look wrong in the Expense Tracker            | `amount` is saved as a String in MockAPI.io. Change it to Number.   |
| The quiz shows "This question has no options"       | `options` is not stored as an array. See step 4.                    |
| A right answer is counted as wrong                  | `answer` does not exactly match one of the `options` strings.        |
| Data resets or looks odd                            | Free MockAPI.io projects are not permanent storage — just re-add rows. |
