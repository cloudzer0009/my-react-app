import { useState, useEffect } from 'react'
import { API_URL, POKEMON_LIST_URL, idFromUrl } from './api'
import SearchBar from './components/SearchBar'
import PokemonGrid from './components/PokemonGrid'
import PokemonDialog from './components/PokemonDialog'
import { Button } from '@/components/ui/button'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'

// How many cards we add to the page each time "Load more" is clicked.
const PAGE_SIZE = 24

function App() {
  // Every Pokemon name we downloaded from PokeAPI
  const [allPokemon, setAllPokemon] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  // What the user typed in the search box (a controlled input)
  const [search, setSearch] = useState('')
  // How many cards we are showing right now
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE)
  // The Pokemon whose details are open (null = the dialog is closed)
  const [selectedName, setSelectedName] = useState(null)

  // GET /pokemon?limit=1400 -> read the name of every Pokemon
  async function loadPokemon() {
    setLoading(true)
    setError('')

    try {
      if (!API_URL) {
        throw new Error('VITE_API_URL is missing. Copy .env.example to .env and add the PokeAPI URL.')
      }

      const response = await fetch(POKEMON_LIST_URL)

      // fetch() does NOT throw on 404 or 500, so we check it ourselves.
      if (!response.ok) {
        throw new Error('Could not load Pokemon (status ' + response.status + ')')
      }

      const data = await response.json()

      // The API gives us { name, url }. We add the id, which we read
      // out of the url, so the cards can show a picture and a number.
      const pokemonWithIds = data.results.map((pokemon) => ({
        name: pokemon.name,
        id: idFromUrl(pokemon.url),
      }))

      setAllPokemon(pokemonWithIds)
    } catch (err) {
      setError(err.message)
    } finally {
      // finally always runs, so the loading message never gets stuck.
      setLoading(false)
    }
  }

  // Load the list once, right after the first render.
  useEffect(() => {
    loadPokemon()
  }, [])

  function handleSearchChange(value) {
    setSearch(value)
    // Start counting from the top again whenever the search changes.
    setVisibleCount(PAGE_SIZE)
  }

  // Derived values: we calculate these from state on every render instead of
  // storing them, so they can never fall out of sync.
  const matchingPokemon = allPokemon.filter((pokemon) =>
    pokemon.name.includes(search.trim().toLowerCase()),
  )

  const visiblePokemon = matchingPokemon.slice(0, visibleCount)
  const hasMore = visibleCount < matchingPokemon.length

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4">
      <div className="mx-auto w-full max-w-5xl">
        <header className="mb-6">
          <h1 className="text-2xl font-bold sm:text-3xl">Pokedex</h1>
          <p className="mt-1 text-sm text-slate-600">
            A React + PokeAPI workshop project.
          </p>
        </header>

        <SearchBar
          search={search}
          onChange={handleSearchChange}
          resultCount={matchingPokemon.length}
          loading={loading}
        />

        {/* Error state */}
        {error && (
          <Alert variant="destructive" className="mt-4">
            <AlertTitle>Something went wrong</AlertTitle>
            <AlertDescription>
              <p>{error}</p>
              <Button size="sm" variant="outline" onClick={loadPokemon}>
                Try again
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {/* Loading state */}
        {loading && (
          <p className="py-16 text-center text-sm text-slate-500">
            Loading Pokemon...
          </p>
        )}

        {/* Empty state - skipped when an error is already on screen */}
        {!loading && !error && matchingPokemon.length === 0 && (
          <p className="py-16 text-center text-sm text-slate-500">
            No Pokemon match "{search}". Try another name.
          </p>
        )}

        {/* The grid of cards */}
        {!loading && visiblePokemon.length > 0 && (
          <PokemonGrid pokemon={visiblePokemon} onSelect={setSelectedName} />
        )}

        {/* "Load more" only appears when there are more results to show */}
        {!loading && hasMore && (
          <div className="mt-6 text-center">
            <Button
              variant="outline"
              onClick={() => setVisibleCount(visibleCount + PAGE_SIZE)}
            >
              Load more
            </Button>
          </div>
        )}

        {/* The dialog only exists while a Pokemon is selected. */}
        {selectedName && (
          <PokemonDialog
            name={selectedName}
            onClose={() => setSelectedName(null)}
          />
        )}
      </div>
    </div>
  )
}

export default App
