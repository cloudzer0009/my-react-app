// A plain object that maps a Pokemon type to some Tailwind classes.
// Objects like this are a simple way to avoid a long chain of if / else.
const typeColors = {
  normal: 'bg-stone-200 text-stone-800',
  fire: 'bg-orange-200 text-orange-900',
  water: 'bg-sky-200 text-sky-900',
  electric: 'bg-yellow-200 text-yellow-900',
  grass: 'bg-green-200 text-green-900',
  ice: 'bg-cyan-200 text-cyan-900',
  fighting: 'bg-red-200 text-red-900',
  poison: 'bg-purple-200 text-purple-900',
  ground: 'bg-amber-200 text-amber-900',
  flying: 'bg-indigo-200 text-indigo-900',
  psychic: 'bg-pink-200 text-pink-900',
  bug: 'bg-lime-200 text-lime-900',
  rock: 'bg-stone-300 text-stone-900',
  ghost: 'bg-violet-200 text-violet-900',
  dragon: 'bg-teal-200 text-teal-900',
  dark: 'bg-slate-300 text-slate-900',
  steel: 'bg-slate-200 text-slate-800',
  fairy: 'bg-rose-200 text-rose-900',
}

export function typeClasses(type) {
  // If we meet a type that is not in the list, fall back to grey.
  return typeColors[type] || 'bg-slate-200 text-slate-800'
}
