// The PokeAPI base URL lives in the .env file so it is never hardcoded
// inside a component.
//
// .env example:
//   VITE_API_URL=https://pokeapi.co/api/v2
//
// Vite only exposes variables that start with VITE_ to the browser.
export const API_URL = import.meta.env.VITE_API_URL

// PokeAPI gives us every Pokemon name in one request. 1400 is comfortably
// more than the number that exists today, so we always get the full list.
export const POKEMON_LIST_URL = `${API_URL}/pokemon?limit=1400`

// The address of one Pokemon, for example .../pokemon/pikachu
export function pokemonUrl(name) {
  return `${API_URL}/pokemon/${name}`
}

// The list response gives us a url like "https://pokeapi.co/api/v2/pokemon/25/".
// The number in the middle is the Pokedex id, so we pull it out of the text.
export function idFromUrl(url) {
  const parts = url.split('/').filter(Boolean)
  return Number(parts[parts.length - 1])
}

// Every Pokemon picture lives at a predictable address, so we can build it
// from the id instead of making another request.
export function artworkUrl(id) {
  return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`
}
