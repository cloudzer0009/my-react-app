import { artworkUrl } from '../api'
import { Card, CardContent } from '@/components/ui/card'

function PokemonCard({ pokemon, onSelect }) {
  return (
    <Card
      // The whole card is a button so it works with a mouse and a keyboard.
      role="button"
      tabIndex={0}
      onClick={() => onSelect(pokemon.name)}
      onKeyDown={(event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault()
          onSelect(pokemon.name)
        }
      }}
      className="cursor-pointer hover:border-slate-400"
    >
      <CardContent className="flex flex-col items-center py-4">
        <img
          src={artworkUrl(pokemon.id)}
          alt={pokemon.name}
          // Tell the browser it can wait until the image is nearly on screen.
          loading="lazy"
          className="h-24 w-24 object-contain"
        />
        <p className="mt-2 text-xs text-slate-500">
          #{String(pokemon.id).padStart(3, '0')}
        </p>
        <p className="text-sm font-medium capitalize">{pokemon.name}</p>
      </CardContent>
    </Card>
  )
}

export default PokemonCard
