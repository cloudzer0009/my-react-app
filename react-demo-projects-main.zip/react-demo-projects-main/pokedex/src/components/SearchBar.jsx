import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'

// Props: the current search text, plus a function to call when it changes.
function SearchBar({ search, onChange, resultCount, loading }) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div className="w-full space-y-2 sm:max-w-sm">
        <Label htmlFor="search">Search by name</Label>
        <Input
          id="search"
          placeholder="pikachu"
          value={search}
          // A controlled input: React state is the single source of truth.
          onChange={(event) => onChange(event.target.value)}
        />
      </div>

      {/* Conditional rendering: hide the count until the list has loaded */}
      {!loading && (
        <Badge variant="secondary">{resultCount} Pokemon found</Badge>
      )}
    </div>
  )
}

export default SearchBar
