import { useState, useEffect } from 'react'
import { pokemonUrl, artworkUrl } from '../api'
import { typeClasses } from '../pokemonTypes'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Progress } from '@/components/ui/progress'

// The highest base stat any Pokemon has, used to size the bars.
const MAX_STAT = 255

function PokemonDialog({ name, onClose }) {
  // This component fetches its own data, so it has its own three states.
  const [pokemon, setPokemon] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  // GET /pokemon/:name -> read the details of one Pokemon.
  //
  // Notice the [name] at the bottom. It means "run this again whenever the
  // name changes", which is different from the [] we use to run once.
  useEffect(() => {
    async function loadDetails() {
      setLoading(true)
      setError('')

      try {
        const response = await fetch(pokemonUrl(name))

        if (!response.ok) {
          throw new Error('Could not load ' + name + ' (status ' + response.status + ')')
        }

        const data = await response.json()
        setPokemon(data)
      } catch (err) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }

    loadDetails()
  }, [name])

  return (
    // `open` is always true here because App.jsx only renders this component
    // while a Pokemon is selected.
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="capitalize">{name}</DialogTitle>
          <DialogDescription>
            Details loaded from PokeAPI when you opened this card.
          </DialogDescription>
        </DialogHeader>

        {/* Loading state */}
        {loading && (
          <p className="py-8 text-center text-sm text-slate-500">Loading details...</p>
        )}

        {/* Error state */}
        {!loading && error && <p className="py-8 text-center text-sm text-red-600">{error}</p>}

        {/* The details */}
        {!loading && !error && pokemon && (
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <img
                src={artworkUrl(pokemon.id)}
                alt={pokemon.name}
                className="h-28 w-28 object-contain"
              />

              <div className="space-y-2">
                <p className="text-sm text-slate-500">
                  #{String(pokemon.id).padStart(3, '0')}
                </p>

                <div className="flex flex-wrap gap-1">
                  {pokemon.types.map((entry) => (
                    <span
                      key={entry.type.name}
                      className={
                        'rounded-full px-2 py-0.5 text-xs font-medium capitalize ' +
                        typeClasses(entry.type.name)
                      }
                    >
                      {entry.type.name}
                    </span>
                  ))}
                </div>

                {/* PokeAPI stores height in decimetres and weight in hectograms */}
                <p className="text-sm text-slate-600">
                  {pokemon.height / 10} m &middot; {pokemon.weight / 10} kg
                </p>
              </div>
            </div>

            <div>
              <p className="text-sm font-medium">Abilities</p>
              <p className="text-sm text-slate-600 capitalize">
                {pokemon.abilities.map((entry) => entry.ability.name).join(', ')}
              </p>
            </div>

            <div className="space-y-2">
              <p className="text-sm font-medium">Base stats</p>
              {pokemon.stats.map((entry) => (
                <div key={entry.stat.name} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="capitalize text-slate-600">{entry.stat.name}</span>
                    <span className="font-medium">{entry.base_stat}</span>
                  </div>
                  <Progress value={(entry.base_stat / MAX_STAT) * 100} />
                </div>
              ))}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

export default PokemonDialog
