import PokemonCard from './PokemonCard'

function PokemonGrid({ pokemon, onSelect }) {
  return (
    <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
      {/* Array.map() turns each Pokemon object into a card */}
      {pokemon.map((item) => (
        <PokemonCard key={item.id} pokemon={item} onSelect={onSelect} />
      ))}
    </div>
  )
}

export default PokemonGrid
