import { useState, useEffect } from 'react'
import { API_URL, TODOS_URL } from './api'
import TodoForm from './components/TodoForm'
import TodoFilters from './components/TodoFilters'
import TodoList from './components/TodoList'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'

function App() {
  // 1. The list of todos that came back from MockAPI.io
  const [todos, setTodos] = useState([])
  // 2. True while we are waiting for the first fetch to finish
  const [loading, setLoading] = useState(true)
  // 3. A message to show when something goes wrong
  const [error, setError] = useState('')
  // 4. Which todos we are currently showing: "all" | "active" | "completed"
  const [filter, setFilter] = useState('all')

  // GET /todos  -> read all todos
  async function loadTodos() {
    setLoading(true)
    setError('')

    try {
      if (!API_URL) {
        throw new Error('VITE_API_URL is missing. Copy .env.example to .env and add your MockAPI.io URL.')
      }

      const response = await fetch(TODOS_URL)

      // fetch() does NOT throw on 404 or 500, so we check it ourselves.
      if (!response.ok) {
        throw new Error('Could not load todos (status ' + response.status + ')')
      }

      const data = await response.json()
      setTodos(data)
    } catch (err) {
      setError(err.message)
    } finally {
      // finally always runs, so the spinner never gets stuck.
      setLoading(false)
    }
  }

  // useEffect runs after the first render.
  // The empty array [] means "only run this once".
  useEffect(() => {
    loadTodos()
  }, [])

  // POST /todos  -> create one todo
  async function addTodo(title) {
    try {
      const response = await fetch(TODOS_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: title, completed: false }),
      })

      if (!response.ok) {
        throw new Error('Could not add the todo')
      }

      const newTodo = await response.json()
      // Put the new todo at the end of the list.
      setTodos([...todos, newTodo])
    } catch (err) {
      setError(err.message)
    }
  }

  // PUT /todos/:id  -> update one todo (used for editing and for completing)
  async function updateTodo(id, changes) {
    try {
      const response = await fetch(`${TODOS_URL}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(changes),
      })

      if (!response.ok) {
        throw new Error('Could not update the todo')
      }

      const updatedTodo = await response.json()
      // Replace the old todo with the updated one.
      setTodos(todos.map((todo) => (todo.id === id ? updatedTodo : todo)))
    } catch (err) {
      setError(err.message)
    }
  }

  // DELETE /todos/:id  -> remove one todo
  async function deleteTodo(id) {
    try {
      const response = await fetch(`${TODOS_URL}/${id}`, { method: 'DELETE' })

      if (!response.ok) {
        throw new Error('Could not delete the todo')
      }

      // Keep every todo except the deleted one.
      setTodos(todos.filter((todo) => todo.id !== id))
    } catch (err) {
      setError(err.message)
    }
  }

  // Derived values: we calculate them from `todos` instead of storing them
  // in their own state. They are always up to date this way.
  const visibleTodos = todos.filter((todo) => {
    if (filter === 'active') return !todo.completed
    if (filter === 'completed') return todo.completed
    return true
  })

  const remainingCount = todos.filter((todo) => !todo.completed).length

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4">
      <div className="mx-auto w-full max-w-2xl">
        <header className="mb-6">
          <h1 className="text-2xl font-bold sm:text-3xl">Todo List</h1>
          <p className="mt-1 text-sm text-slate-600">
            A React + MockAPI.io workshop project.
          </p>
        </header>

        <Card>
          <CardHeader>
            <CardTitle>My tasks</CardTitle>
          </CardHeader>

          <CardContent className="space-y-4">
            <TodoForm onAdd={addTodo} />

            {/* Conditional rendering: only show the error box when there is an error */}
            {error && (
              <Alert variant="destructive">
                <AlertTitle>Something went wrong</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <TodoFilters
              filter={filter}
              onChange={setFilter}
              remainingCount={remainingCount}
            />

            {/* Loading state */}
            {loading && (
              <p className="py-8 text-center text-sm text-slate-500">Loading todos...</p>
            )}

            {/* Empty state - skipped when an error is already on screen */}
            {!loading && !error && visibleTodos.length === 0 && (
              <p className="py-8 text-center text-sm text-slate-500">
                {todos.length === 0
                  ? 'No todos yet. Add your first task above.'
                  : 'No todos match this filter.'}
              </p>
            )}

            {/* The list itself */}
            {!loading && visibleTodos.length > 0 && (
              <TodoList
                todos={visibleTodos}
                onUpdate={updateTodo}
                onDelete={deleteTodo}
              />
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default App
