import ExpenseForm from './ExpenseForm'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'

function EditExpenseDialog({ expense, onSave, onClose }) {
  return (
    // `open` is always true here because App.jsx only renders this component
    // while an expense is being edited.
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit expense</DialogTitle>
          <DialogDescription>
            Update the values and save to send a PUT request to MockAPI.io.
          </DialogDescription>
        </DialogHeader>

        {/* We reuse the same form we use for adding expenses. */}
        <ExpenseForm
          expense={expense}
          submitLabel="Save Changes"
          onSubmit={(updated) => onSave(expense.id, updated)}
        />
      </DialogContent>
    </Dialog>
  )
}

export default EditExpenseDialog
