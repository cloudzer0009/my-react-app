import { formatCurrency } from '../format'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

function ExpenseItem({ expense, onEdit, onDelete }) {
  return (
    <li className="flex flex-col gap-3 p-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="min-w-0">
        <p className="truncate text-sm font-medium">{expense.description}</p>
        <Badge variant="secondary" className="mt-1">
          {expense.category}
        </Badge>
      </div>

      <div className="flex items-center justify-between gap-3 sm:justify-end">
        <p className="text-sm font-semibold">{formatCurrency(expense.amount)}</p>

        <div className="flex gap-2">
          {/* Passing the whole expense back up so App.jsx can open the dialog */}
          <Button size="sm" variant="outline" onClick={() => onEdit(expense)}>
            Edit
          </Button>
          <Button size="sm" variant="destructive" onClick={() => onDelete(expense.id)}>
            Delete
          </Button>
        </div>
      </div>
    </li>
  )
}

export default ExpenseItem
