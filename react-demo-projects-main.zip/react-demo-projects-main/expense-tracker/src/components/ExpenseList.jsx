import ExpenseItem from './ExpenseItem'

function ExpenseList({ expenses, onEdit, onDelete }) {
  return (
    <ul className="divide-y rounded-md border">
      {/* Array.map() turns each expense object into a row */}
      {expenses.map((expense) => (
        <ExpenseItem
          key={expense.id}
          expense={expense}
          onEdit={onEdit}
          onDelete={onDelete}
        />
      ))}
    </ul>
  )
}

export default ExpenseList
