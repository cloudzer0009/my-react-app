import { useState } from 'react'
import { CATEGORIES } from '../api'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

// This form is used twice: to add a new expense and to edit an existing one.
// `expense` is optional - when it is given, the inputs start with its values.
function ExpenseForm({ onSubmit, expense, submitLabel = 'Add Expense' }) {
  // Three controlled inputs, one piece of state each.
  const [description, setDescription] = useState(expense ? expense.description : '')
  const [amount, setAmount] = useState(expense ? String(expense.amount) : '')
  const [category, setCategory] = useState(expense ? expense.category : 'Food')
  const [formError, setFormError] = useState('')

  function handleSubmit(event) {
    event.preventDefault()

    if (description.trim() === '') {
      setFormError('Please enter a description.')
      return
    }

    // Number() turns the text from the input into a real number.
    const parsedAmount = Number(amount)

    if (!amount || Number.isNaN(parsedAmount) || parsedAmount <= 0) {
      setFormError('Please enter an amount greater than 0.')
      return
    }

    setFormError('')

    onSubmit({
      description: description.trim(),
      amount: parsedAmount,
      category: category,
    })

    // Only clear the form when we are adding a brand new expense.
    if (!expense) {
      setDescription('')
      setAmount('')
      setCategory('Food')
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Input
          id="description"
          placeholder="Lunch"
          value={description}
          onChange={(event) => setDescription(event.target.value)}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="amount">Amount</Label>
        <Input
          id="amount"
          type="number"
          min="0"
          step="0.01"
          placeholder="150"
          value={amount}
          onChange={(event) => setAmount(event.target.value)}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="category">Category</Label>
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger id="category" className="w-full">
            <SelectValue placeholder="Choose a category" />
          </SelectTrigger>
          <SelectContent>
            {CATEGORIES.map((name) => (
              <SelectItem key={name} value={name}>
                {name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Conditional rendering: the message only appears when there is a problem */}
      {formError && <p className="text-sm text-red-600">{formError}</p>}

      <Button type="submit" className="w-full">
        {submitLabel}
      </Button>
    </form>
  )
}

export default ExpenseForm
