import { CATEGORIES } from '../api'
import { formatCurrency } from '../format'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

function CategoryTotals({ expenses }) {
  // For each category, keep only the expenses that belong to it and add them up.
  const rows = CATEGORIES.map((category) => {
    const expensesInCategory = expenses.filter(
      (expense) => expense.category === category,
    )

    const total = expensesInCategory.reduce(
      (sum, expense) => sum + Number(expense.amount),
      0,
    )

    return { category, total, count: expensesInCategory.length }
  })

  // Hide categories that have no expenses yet.
  const usedRows = rows.filter((row) => row.count > 0)

  return (
    <Card>
      <CardHeader>
        <CardTitle>By category</CardTitle>
      </CardHeader>
      <CardContent>
        {usedRows.length === 0 ? (
          <p className="text-sm text-slate-500">Nothing to show yet.</p>
        ) : (
          <ul className="space-y-2">
            {usedRows.map((row) => (
              <li
                key={row.category}
                className="flex items-center justify-between text-sm"
              >
                <span className="text-slate-600">
                  {row.category} ({row.count})
                </span>
                <span className="font-medium">{formatCurrency(row.total)}</span>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  )
}

export default CategoryTotals
