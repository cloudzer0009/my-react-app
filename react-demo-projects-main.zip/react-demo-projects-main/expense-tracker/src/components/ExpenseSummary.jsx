import { formatCurrency } from '../format'
import { Card, CardContent } from '@/components/ui/card'

// Every number here is calculated from the `expenses` array on each render.
// We never store totals in their own useState - that would get out of sync.
function ExpenseSummary({ expenses }) {
  const total = expenses.reduce((sum, expense) => sum + Number(expense.amount), 0)

  const count = expenses.length

  const highest = expenses.reduce((biggest, expense) => {
    return Number(expense.amount) > Number(biggest.amount) ? expense : biggest
  }, expenses[0] || null)

  return (
    <div className="grid gap-4 sm:grid-cols-3">
      <Card>
        <CardContent className="py-4">
          <p className="text-sm text-slate-600">Total expenses</p>
          <p className="mt-1 text-xl font-bold">{formatCurrency(total)}</p>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="py-4">
          <p className="text-sm text-slate-600">Number of expenses</p>
          <p className="mt-1 text-xl font-bold">{count}</p>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="py-4">
          <p className="text-sm text-slate-600">Highest expense</p>
          <p className="mt-1 text-xl font-bold">
            {highest ? formatCurrency(highest.amount) : formatCurrency(0)}
          </p>
          {highest && (
            <p className="mt-1 truncate text-xs text-slate-500">
              {highest.description}
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default ExpenseSummary
