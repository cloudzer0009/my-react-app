import { useState, useEffect } from 'react'
import { API_URL, EXPENSES_URL } from './api'
import ExpenseForm from './components/ExpenseForm'
import ExpenseList from './components/ExpenseList'
import ExpenseSummary from './components/ExpenseSummary'
import CategoryTotals from './components/CategoryTotals'
import EditExpenseDialog from './components/EditExpenseDialog'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'

function App() {
  // Everything we downloaded from MockAPI.io
  const [expenses, setExpenses] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  // The expense the user is editing right now (null = the dialog is closed)
  const [editingExpense, setEditingExpense] = useState(null)

  // GET /expenses -> read every expense
  async function loadExpenses() {
    setLoading(true)
    setError('')

    try {
      if (!API_URL) {
        throw new Error('VITE_API_URL is missing. Copy .env.example to .env and add your MockAPI.io URL.')
      }

      const response = await fetch(EXPENSES_URL)

      if (!response.ok) {
        throw new Error('Could not load expenses (status ' + response.status + ')')
      }

      const data = await response.json()
      setExpenses(data)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  // Load the expenses once, right after the first render.
  useEffect(() => {
    loadExpenses()
  }, [])

  // POST /expenses -> create one expense
  async function addExpense(expense) {
    try {
      const response = await fetch(EXPENSES_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(expense),
      })

      if (!response.ok) {
        throw new Error('Could not add the expense')
      }

      const newExpense = await response.json()
      setExpenses([...expenses, newExpense])
    } catch (err) {
      setError(err.message)
    }
  }

  // PUT /expenses/:id -> update one expense
  async function updateExpense(id, expense) {
    try {
      const response = await fetch(`${EXPENSES_URL}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(expense),
      })

      if (!response.ok) {
        throw new Error('Could not update the expense')
      }

      const updatedExpense = await response.json()
      setExpenses(
        expenses.map((item) => (item.id === id ? updatedExpense : item)),
      )
      setEditingExpense(null) // close the dialog
    } catch (err) {
      setError(err.message)
    }
  }

  // DELETE /expenses/:id -> remove one expense
  async function deleteExpense(id) {
    try {
      const response = await fetch(`${EXPENSES_URL}/${id}`, { method: 'DELETE' })

      if (!response.ok) {
        throw new Error('Could not delete the expense')
      }

      setExpenses(expenses.filter((item) => item.id !== id))
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4">
      <div className="mx-auto w-full max-w-4xl">
        <header className="mb-6">
          <h1 className="text-2xl font-bold sm:text-3xl">Expense Tracker</h1>
          <p className="mt-1 text-sm text-slate-600">
            A React + MockAPI.io workshop project.
          </p>
        </header>

        {/* Error state */}
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertTitle>Something went wrong</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* The totals are calculated inside ExpenseSummary from this same list. */}
        <ExpenseSummary expenses={expenses} />

        <div className="mt-4 grid gap-4 md:grid-cols-3">
          <div className="md:col-span-1 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Add an expense</CardTitle>
              </CardHeader>
              <CardContent>
                <ExpenseForm onSubmit={addExpense} />
              </CardContent>
            </Card>

            <CategoryTotals expenses={expenses} />
          </div>

          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>Expenses</CardTitle>
            </CardHeader>
            <CardContent>
              {/* Loading state */}
              {loading && (
                <p className="py-8 text-center text-sm text-slate-500">
                  Loading expenses...
                </p>
              )}

              {/* Empty state - skipped when an error is already on screen */}
              {!loading && !error && expenses.length === 0 && (
                <p className="py-8 text-center text-sm text-slate-500">
                  No expenses yet. Add your first one on the left.
                </p>
              )}

              {/* The list itself */}
              {!loading && expenses.length > 0 && (
                <ExpenseList
                  expenses={expenses}
                  onEdit={setEditingExpense}
                  onDelete={deleteExpense}
                />
              )}
            </CardContent>
          </Card>
        </div>

        {/* The dialog only exists while an expense is being edited. */}
        {editingExpense && (
          <EditExpenseDialog
            expense={editingExpense}
            onSave={updateExpense}
            onClose={() => setEditingExpense(null)}
          />
        )}
      </div>
    </div>
  )
}

export default App
