// A small helper so every component shows money the same way.
// Change 'en-PH' / 'PHP' if you want a different currency.
export function formatCurrency(value) {
  return new Intl.NumberFormat('en-PH', {
    style: 'currency',
    currency: 'PHP',
  }).format(Number(value) || 0)
}
