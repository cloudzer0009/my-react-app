# Expense Tracker

A beginner-friendly React application that stores expenses in [MockAPI.io](https://mockapi.io/?utm_source=chatgpt.com).

## Project Overview

This app keeps track of what you spend:

- See every expense you have recorded
- Add an expense (description, amount, category)
- Edit an expense in a dialog
- Delete an expense
- Choose a category: Food, Transportation, Shopping, Entertainment, Bills, Other
- See your **total spent**, the **number of expenses**, and your **highest expense**
- See a breakdown of spending **by category**
- Friendly **loading**, **error**, and **empty** screens

All totals are calculated from the expense list on every render — they are never stored in their own state, so they can never go out of sync.

## Technologies

- **React** – builds the user interface out of components
- **Vite** – the dev server and build tool
- **Tailwind CSS** – utility classes for styling
- **shadcn/ui** – ready-made, accessible components (Button, Card, Input, Label, Select, Dialog, Badge, Alert)
- **MockAPI.io** – a free fake REST API that acts as our backend
- **Fetch API** – how the browser talks to MockAPI.io

## Prerequisites

- [Node.js](https://nodejs.org/) (version 20 or newer)
- npm (comes with Node.js)
- [Git](https://git-scm.com/)
- A free [MockAPI.io](https://mockapi.io/?utm_source=chatgpt.com) account

If you have not created your MockAPI.io project yet, follow **[../MOCKAPI_SETUP.md](../MOCKAPI_SETUP.md)** first.

## Installation

```bash
npm install
```

## Environment Setup

Copy:

```text
.env.example
```

to:

```text
.env
```

On macOS / Linux:

```bash
cp .env.example .env
```

On Windows (PowerShell):

```powershell
Copy-Item .env.example .env
```

Then open `.env` and paste in your own MockAPI.io URL:

```env
VITE_API_URL=https://YOUR_PROJECT_ID.mockapi.io/api/v1
```

Notes:

- Do **not** put `/expenses` at the end. The app adds it for you.
- Variables must start with `VITE_` or Vite will not pass them to the browser.
- Restart `npm run dev` after changing `.env`.
- `.env` is listed in `.gitignore`, so your URL is never committed.

## Run the Project

```bash
npm run dev
```

Then open the address Vite prints (usually http://localhost:5173).

## Build

```bash
npm run build
```

## Preview

```bash
npm run preview
```

## API

This app uses one MockAPI.io resource: **`expenses`**.

| Field         | Type   | Example     |
| ------------- | ------ | ----------- |
| `description` | string | `"Lunch"`   |
| `amount`      | number | `150`       |
| `category`    | string | `"Food"`    |

Example record:

```json
{
  "description": "Lunch",
  "amount": 150,
  "category": "Food"
}
```

| Method   | Endpoint         | Used for                             |
| -------- | ---------------- | ------------------------------------ |
| `GET`    | `/expenses`      | Loading the list when the page opens |
| `POST`   | `/expenses`      | Adding a new expense                 |
| `PUT`    | `/expenses/:id`  | Saving an edit                       |
| `DELETE` | `/expenses/:id`  | Removing an expense                  |

All of these live in `src/App.jsx`. The base URL comes from `src/api.js`:

```js
export const API_URL = import.meta.env.VITE_API_URL
export const EXPENSES_URL = `${API_URL}/expenses`
```

## Project Structure

```text
src/
├── components/
│   ├── ui/                     # shadcn/ui components
│   ├── ExpenseForm.jsx         # used for both adding and editing
│   ├── ExpenseList.jsx         # maps over the expenses
│   ├── ExpenseItem.jsx         # one row: amount, category, edit, delete
│   ├── ExpenseSummary.jsx      # total, count, highest
│   ├── CategoryTotals.jsx      # spending per category
│   └── EditExpenseDialog.jsx   # the edit dialog
├── api.js                      # reads VITE_API_URL + the category list
├── format.js                   # formats numbers as money
├── App.jsx                     # state + all fetch calls
├── main.jsx                    # starts React
└── index.css                   # Tailwind + theme
```

The currency is Philippine Peso by default. Change it in `src/format.js` if you like.

## Learning Objectives

By reading and changing this project you practise:

- **Components and props** – one `ExpenseForm` is reused for adding *and* editing
- **useState** – expenses, loading, error, the expense being edited, and every form field
- **useEffect** – loading the expenses once, right after the first render
- **Event handlers** – `onClick`, `onChange`, `onSubmit`, `onValueChange`
- **Forms and controlled inputs** – description, amount, and category all come from state
- **Form validation** – rejecting an empty description or an amount of 0
- **Conditional rendering** – loading vs. error vs. empty vs. the list, and the dialog
- **`Array.map()`** – turning expenses into rows, and categories into options
- **`Array.filter()` and `Array.reduce()`** – totals, highest expense, per-category sums
- **Derived state** – totals are calculated during render instead of stored
- **Fetch API with async/await** – GET, POST, PUT, DELETE

### Things to try on your own

1. Add a filter so you only see one category at a time.
2. Sort the list from the largest amount to the smallest.
3. Add a date field to each expense and show this month's total.
